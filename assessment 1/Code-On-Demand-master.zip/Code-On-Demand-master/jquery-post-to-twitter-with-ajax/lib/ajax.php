<?php
require_once( 'TwitterPost.php' );
$tweet = new TwitterPost();
$tweet->send();