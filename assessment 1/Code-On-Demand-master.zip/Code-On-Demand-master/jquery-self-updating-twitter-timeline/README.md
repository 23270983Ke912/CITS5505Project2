# jQuery: self-updating Twitter timeline

To get the demo working, open lib/TwitterGet.php and insert your Twitter API’s credentials.