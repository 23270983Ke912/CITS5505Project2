<?php
require_once( 'TwitterGet.php' );
$tweets = new TwitterGet();
$tweets->fetch();