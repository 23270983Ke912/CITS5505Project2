<?php
require_once( 'AJAXPoll.php' );
$ajaxPoll = new AJAXPoll();
$ajaxPoll->handleRequest();