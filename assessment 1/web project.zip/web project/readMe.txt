The project is created by XINYU WANG 23631069. 9/4/2022

I have used ajax call in the history page.

If you did not access index.html file via a server, you will be expected to experience an
error which says the json file is blocked by CORS policy.

But no worries, I have listed all possible solutions to this error, you will explore these
two solutions as you interacting with pages.

An effect in the page (progress bar and ) is from w3 school, the link is available in the script.js file.

Thank you so much for your time on viewing my pages
