
document.getElementById('exampleloading').innerHTML = 'script loaded from other js file';